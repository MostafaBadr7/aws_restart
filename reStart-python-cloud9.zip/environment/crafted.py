Listt = []
myVehicle1 = {
    "vin" : "TMX20122",
    "make" : "AnyCompany Motors" ,
    "model" : "Coupe" ,
    "year" : 2012,
    "range" : 355,
    "topSpeed" : 155,
    "zeroSixty" : 4.1,
    "mileage" : 50000
}
myVehicle2 = {
    "vin" : "TM320163",
    "make" : "AnyCompany Motors" ,
    "model" : "Sedan" ,
    "year" : 2016,
    "range" : 240,
    "topSpeed" : 140,
    "zeroSixty" : 5.2,
    "mileage" : 20000
}
myVehicle3 = {
    "vin" : "TMX20121",
    "make" : "AnyCompany Motors" ,
    "model" : "SUV" ,
    "year" : 2012,
    "range" : 295,
    "topSpeed" : 155,
    "zeroSixty" :4.7,
    "mileage" : 100000
}
myVehicle4 = {
    "vin" : "TMX20204",
    "make" : "AnyCompany Motors" ,
    "model" : "Truck" ,
    "year" : 2020,
    "range" : 300,
    "topSpeed" : 155,
    "zeroSixty" : 3.5,
    "mileage" : 0
}

Listt = myVehicle1, myVehicle2, myVehicle3, myVehicle4
'''''
Listt.append(myVehicle1) 
Listt.append(myVehicle2) 
Listt.append(myVehicle3) 
Listt.append(myVehicle4)
'''''
for myVehicle in Listt:
 for value in myVehicle.model:
    print ('{} '.format(value))
    print("-----")
