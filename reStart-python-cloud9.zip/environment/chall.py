
str Firstname = 
Fullname = input('Please enter your full name maximum 4 names')

Fullname[0]= Firstname
Fullname[1]= Secondname
Fullname[2]= Lastname

